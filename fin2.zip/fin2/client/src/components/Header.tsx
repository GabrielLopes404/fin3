import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Menu, X, Sparkles } from "lucide-react";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function Header() {
  const [, setLocation] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <motion.header 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ type: "spring", stiffness: 100, damping: 20 }}
      className={`fixed top-0 left-0 right-0 z-50 h-16 transition-all duration-500 ${
        scrolled 
          ? 'bg-background/80 backdrop-blur-xl border-b shadow-lg' 
          : 'bg-background/60 backdrop-blur-md border-b border-transparent'
      }`}
    >
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group" data-testid="link-home">
          <motion.div 
            className="relative"
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 400, damping: 10 }}
          >
            <div className="text-2xl font-bold bg-gradient-to-r from-primary via-primary to-primary/70 bg-clip-text text-transparent">
              LUCREI
            </div>
            <motion.div
              className="absolute -inset-1 bg-gradient-to-r from-primary/20 to-primary/5 rounded-lg blur opacity-0 group-hover:opacity-100 transition-opacity duration-500"
              style={{ zIndex: -1 }}
            />
          </motion.div>
        </Link>

        <nav className="hidden md:flex items-center gap-8">
          {['Benefícios', 'Preços', 'Depoimentos'].map((item, i) => (
            <Link 
              key={item}
              href={`#${item.toLowerCase()}`}
              className="relative text-sm font-medium group"
              data-testid={`link-${item.toLowerCase()}`}
            >
              <motion.span
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="relative z-10 transition-colors duration-300 group-hover:text-primary"
              >
                {item}
              </motion.span>
              <motion.div
                className="absolute -bottom-1 left-0 h-0.5 bg-gradient-to-r from-primary to-primary/50 rounded-full"
                initial={{ width: 0 }}
                whileHover={{ width: '100%' }}
                transition={{ duration: 0.3 }}
              />
            </Link>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-3">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
          >
            <Button 
              variant="ghost" 
              className="relative overflow-hidden group" 
              data-testid="button-login"
              onClick={() => setLocation('/login')}
            >
              <span className="relative z-10">Entrar</span>
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent"
                initial={{ x: '-100%' }}
                whileHover={{ x: 0 }}
                transition={{ duration: 0.3 }}
              />
            </Button>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 }}
            whileHover={{ scale: 1.02 }}
          >
            <Button 
              className="relative overflow-hidden group shadow-lg shadow-primary/20" 
              data-testid="button-cta-header"
              onClick={() => setLocation('/register')}
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-primary via-primary to-primary/80"
                animate={{
                  backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "linear"
                }}
                style={{
                  backgroundSize: '200% 100%'
                }}
              />
              <span className="relative z-10 flex items-center gap-2">
                <Sparkles className="h-4 w-4" />
                Começar agora — 7 dias grátis
              </span>
            </Button>
          </motion.div>
        </div>

        <motion.button
          whileTap={{ scale: 0.95 }}
          className="md:hidden p-2 hover-elevate rounded-lg"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          data-testid="button-mobile-menu"
        >
          <AnimatePresence mode="wait">
            {mobileMenuOpen ? (
              <motion.div
                key="close"
                initial={{ rotate: -90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: 90, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <X size={24} />
              </motion.div>
            ) : (
              <motion.div
                key="menu"
                initial={{ rotate: 90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: -90, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <Menu size={24} />
              </motion.div>
            )}
          </AnimatePresence>
        </motion.button>
      </div>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="md:hidden border-t bg-background/95 backdrop-blur-xl overflow-hidden"
            data-testid="mobile-menu"
          >
            <nav className="flex flex-col p-4 gap-4">
              {['Benefícios', 'Preços', 'Depoimentos'].map((item, i) => (
                <motion.div
                  key={item}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                >
                  <Link 
                    href={`#${item.toLowerCase()}`}
                    className="text-sm font-medium py-2 block hover:text-primary transition-colors"
                    data-testid={`link-mobile-${item.toLowerCase()}`}
                  >
                    {item}
                  </Link>
                </motion.div>
              ))}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="flex flex-col gap-2 pt-2"
              >
                <Button 
                  variant="ghost" 
                  className="w-full" 
                  data-testid="button-mobile-login"
                  onClick={() => setLocation('/login')}
                >
                  Entrar
                </Button>
                <Button 
                  className="w-full shadow-lg shadow-primary/20" 
                  data-testid="button-mobile-cta"
                  onClick={() => setLocation('/register')}
                >
                  Começar agora — 7 dias grátis
                </Button>
              </motion.div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
