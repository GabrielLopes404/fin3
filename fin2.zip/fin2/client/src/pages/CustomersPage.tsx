import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { maskPhone, maskCPFCNPJ, maskZipCode, fetchAddressFromCEP, isValidCPF, isValidCNPJ } from "@/lib/masks";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { Plus, Pencil, Trash2, Mail, Phone, Loader2, Search, Users, UserPlus, Building2, MapPin, FileText, Filter, X, ArrowUpDown } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { motion, AnimatePresence } from "framer-motion";

interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  document: string | null;
  address: string | null;
  city: string | null;
  state: string | null;
  zipCode: string | null;
  notes: string | null;
  createdAt: string;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05
    }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 100 }
  }
};

export default function CustomersPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [deleteCustomerId, setDeleteCustomerId] = useState<string | null>(null);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState<string>("all");
  const [sortBy, setSortBy] = useState<"name" | "email" | "createdAt">("name");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");
  const [csrfToken, setCsrfToken] = useState("");
  const [documentError, setDocumentError] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    document: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    notes: "",
  });

  useEffect(() => {
    fetch("/api/csrf-token", { credentials: "include" })
      .then((res) => res.json())
      .then((data) => setCsrfToken(data.csrfToken))
      .catch(() => {});
  }, []);

  const handlePhoneChange = (value: string) => {
    setFormData(prev => ({ ...prev, phone: maskPhone(value) }));
  };

  const handleDocumentChange = async (value: string) => {
    const masked = maskCPFCNPJ(value);
    setFormData(prev => ({ ...prev, document: masked }));
    setDocumentError("");
    
    const numbers = masked.replace(/\D/g, '');
    if (numbers.length === 11) {
      if (!isValidCPF(masked)) {
        setDocumentError("CPF inválido");
      }
    } else if (numbers.length === 14) {
      if (!isValidCNPJ(masked)) {
        setDocumentError("CNPJ inválido");
      }
    }
  };

  const handleZipCodeChange = async (value: string) => {
    const masked = maskZipCode(value);
    setFormData(prev => ({ ...prev, zipCode: masked }));
    
    if (masked.replace(/\D/g, '').length === 8) {
      const addressData = await fetchAddressFromCEP(masked);
      if (addressData) {
        setFormData(prev => ({
          ...prev,
          address: addressData.logradouro || prev.address,
          city: addressData.localidade || prev.city,
          state: addressData.uf || prev.state,
        }));
      }
    }
  };

  const { data: customersData, isLoading } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
    queryFn: async () => {
      const res = await fetch("/api/customers", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch customers");
      const data = await res.json();
      return Array.isArray(data) ? data : [];
    },
  });

  const customers = Array.isArray(customersData) ? customersData : [];

  const createMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const res = await fetch("/api/customers", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken
        },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create customer");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/customers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/metrics"] });
      toast({ 
        title: "Cliente criado com sucesso!",
        description: "O cliente foi adicionado à sua base."
      });
      setIsCreateOpen(false);
      resetForm();
    },
    onError: (error: Error) => {
      toast({ 
        variant: "destructive", 
        title: "Erro ao criar cliente",
        description: error.message || "Tente novamente mais tarde."
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: typeof formData }) => {
      const res = await fetch(`/api/customers/${id}`, {
        method: "PUT",
        headers: { 
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken
        },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to update customer");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/customers"] });
      toast({ 
        title: "Cliente atualizado!",
        description: "As informações foram salvas."
      });
      setIsEditOpen(false);
      setSelectedCustomer(null);
      resetForm();
    },
    onError: (error: Error) => {
      toast({ 
        variant: "destructive", 
        title: "Erro ao atualizar cliente",
        description: error.message || "Tente novamente mais tarde."
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/customers/${id}`, {
        method: "DELETE",
        headers: {
          "X-CSRF-Token": csrfToken
        },
        credentials: "include",
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to delete customer");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/customers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/metrics"] });
      toast({ 
        title: "Cliente deletado!",
        description: "O cliente foi removido da base."
      });
      setDeleteCustomerId(null);
    },
    onError: (error: Error) => {
      toast({ 
        variant: "destructive", 
        title: "Erro ao deletar cliente",
        description: error.message || "Tente novamente mais tarde."
      });
    },
  });

  const resetForm = () => {
    setFormData({
      name: "",
      email: "",
      phone: "",
      document: "",
      address: "",
      city: "",
      state: "",
      zipCode: "",
      notes: "",
    });
    setDocumentError("");
  };

  const handleCreate = () => {
    resetForm();
    setIsCreateOpen(true);
  };

  const handleEdit = (customer: Customer) => {
    setSelectedCustomer(customer);
    setFormData({
      name: customer.name,
      email: customer.email,
      phone: customer.phone || "",
      document: customer.document || "",
      address: customer.address || "",
      city: customer.city || "",
      state: customer.state || "",
      zipCode: customer.zipCode || "",
      notes: customer.notes || "",
    });
    setIsEditOpen(true);
  };

  const handleDeleteClick = (id: string) => {
    setDeleteCustomerId(id);
  };

  const handleDeleteConfirm = () => {
    if (deleteCustomerId) {
      deleteMutation.mutate(deleteCustomerId);
    }
  };

  const filteredCustomers = (customers || [])
    .filter((customer) => {
      const matchesSearch = !searchTerm || (
        customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.phone?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.document?.toLowerCase().includes(searchTerm.toLowerCase())
      );

      const matchesFilter = filterType === "all" || (
        filterType === "with-phone" ? !!customer.phone :
        filterType === "with-email" ? !!customer.email :
        filterType === "with-address" ? !!customer.address :
        filterType === "with-document" ? !!customer.document :
        true
      );

      return matchesSearch && matchesFilter;
    })
    .sort((a, b) => {
      let compareValue = 0;
      
      if (sortBy === "name") {
        compareValue = a.name.localeCompare(b.name);
      } else if (sortBy === "email") {
        compareValue = a.email.localeCompare(b.email);
      } else if (sortBy === "createdAt") {
        compareValue = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      }

      return sortOrder === "asc" ? compareValue : -compareValue;
    });

  const stats = {
    total: customers?.length || 0,
    withEmail: (customers ?? []).filter(c => c.email).length,
    withPhone: (customers ?? []).filter(c => c.phone).length,
    withAddress: (customers ?? []).filter(c => c.address).length,
    withDocument: (customers ?? []).filter(c => c.document).length,
  };

  return (
    <AppLayout>
      <motion.div 
        className="space-y-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Header */}
        <motion.div variants={itemVariants} className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight bg-gradient-to-r from-violet-600 via-purple-600 to-cyan-600 bg-clip-text text-transparent">
              Clientes
            </h1>
            <p className="text-sm sm:text-base text-muted-foreground mt-1">
              Gerencie seus clientes e informações de contato
            </p>
          </div>
          <Button onClick={handleCreate} size="lg" className="gap-2 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700 shadow-lg">
            <Plus className="h-5 w-5" />
            <span className="hidden sm:inline">Novo Cliente</span>
            <span className="sm:hidden">Novo</span>
          </Button>
        </motion.div>

        {/* Stats Cards */}
        <motion.div variants={itemVariants} className="grid gap-4 grid-cols-2 sm:grid-cols-4">
          <motion.div whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 300 }}>
            <Card className="relative overflow-hidden border-violet-500/20 hover:border-violet-500/40 transition-all duration-300 shadow-lg hover:shadow-xl bg-gradient-to-br from-violet-500/5 to-transparent">
              <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-violet-500/10 to-transparent rounded-full blur-2xl" />
              <CardHeader className="pb-2">
                <CardTitle className="text-xs sm:text-sm font-medium text-muted-foreground">Total de Clientes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 sm:gap-3">
                  <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-lg">
                    <Users className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                  </div>
                  <div className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">
                    {stats.total}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 300 }}>
            <Card className="relative overflow-hidden border-cyan-500/20 hover:border-cyan-500/40 transition-all duration-300 shadow-lg hover:shadow-xl bg-gradient-to-br from-cyan-500/5 to-transparent">
              <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-cyan-500/10 to-transparent rounded-full blur-2xl" />
              <CardHeader className="pb-2">
                <CardTitle className="text-xs sm:text-sm font-medium text-muted-foreground">Com Email</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 sm:gap-3">
                  <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg">
                    <Mail className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                  </div>
                  <div className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-purple-600 to-purple-400 bg-clip-text text-transparent">
                    {stats.withEmail}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 300 }}>
            <Card className="relative overflow-hidden border-purple-500/20 hover:border-purple-500/40 transition-all duration-300 shadow-lg hover:shadow-xl bg-gradient-to-br from-purple-500/5 to-transparent">
              <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-purple-500/10 to-transparent rounded-full blur-2xl" />
              <CardHeader className="pb-2">
                <CardTitle className="text-xs sm:text-sm font-medium text-muted-foreground">Com Telefone</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 sm:gap-3">
                  <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-lg bg-gradient-to-br from-purple-500 to-rose-600 flex items-center justify-center shadow-lg">
                    <Phone className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                  </div>
                  <div className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-purple-600 to-rose-600 bg-clip-text text-transparent">
                    {stats.withPhone}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 300 }}>
            <Card className="relative overflow-hidden border-green-500/20 hover:border-green-500/40 transition-all duration-300 shadow-lg hover:shadow-xl bg-gradient-to-br from-green-500/5 to-transparent">
              <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-green-500/10 to-transparent rounded-full blur-2xl" />
              <CardHeader className="pb-2">
                <CardTitle className="text-xs sm:text-sm font-medium text-muted-foreground">Com Endereço</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 sm:gap-3">
                  <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-lg bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center shadow-lg">
                    <MapPin className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                  </div>
                  <div className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-purple-600 to-purple-400 bg-clip-text text-transparent">
                    {stats.withAddress}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>

        {/* Search and Filters */}
        <motion.div variants={itemVariants}>
          <Card className="shadow-xl border-border/50">
            <CardContent className="pt-6">
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="Buscar por nome, email, telefone ou documento..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <div className="flex gap-2">
                    {searchTerm && (
                      <Button variant="outline" size="icon" onClick={() => setSearchTerm("")}>
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>

                {/* Advanced Filters */}
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm font-semibold text-muted-foreground flex items-center gap-2">
                    <Filter className="h-4 w-4" />
                    Filtrar por:
                  </span>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant={filterType === "all" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFilterType("all")}
                      className={filterType === "all" ? "bg-gradient-to-r from-violet-600 to-purple-600" : ""}
                    >
                      Todos ({customers?.length || 0})
                    </Button>
                    <Button
                      variant={filterType === "with-phone" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFilterType("with-phone")}
                      className={filterType === "with-phone" ? "bg-gradient-to-r from-violet-600 to-purple-600" : ""}
                    >
                      <Phone className="h-3 w-3 mr-1" />
                      Com Telefone ({stats.withPhone})
                    </Button>
                    <Button
                      variant={filterType === "with-email" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFilterType("with-email")}
                      className={filterType === "with-email" ? "bg-gradient-to-r from-purple-600 to-purple-400" : ""}
                    >
                      <Mail className="h-3 w-3 mr-1" />
                      Com Email ({stats.withEmail})
                    </Button>
                    <Button
                      variant={filterType === "with-address" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFilterType("with-address")}
                      className={filterType === "with-address" ? "bg-gradient-to-r from-purple-600 to-purple-400" : ""}
                    >
                      <MapPin className="h-3 w-3 mr-1" />
                      Com Endereço ({stats.withAddress})
                    </Button>
                    <Button
                      variant={filterType === "with-document" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFilterType("with-document")}
                      className={filterType === "with-document" ? "bg-gradient-to-r from-orange-600 to-amber-600" : ""}
                    >
                      <FileText className="h-3 w-3 mr-1" />
                      Com Documento ({stats.withDocument})
                    </Button>
                  </div>
                </div>

                {/* Sorting */}
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm font-semibold text-muted-foreground flex items-center gap-2">
                    <ArrowUpDown className="h-4 w-4" />
                    Ordenar:
                  </span>
                  <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
                    <SelectTrigger className="w-[180px] h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="name">Nome</SelectItem>
                      <SelectItem value="email">Email</SelectItem>
                      <SelectItem value="createdAt">Data de Cadastro</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSortOrder(sortOrder === "asc" ? "desc" : "asc")}
                  >
                    {sortOrder === "asc" ? "A → Z" : "Z → A"}
                  </Button>
                </div>

                {/* Active Filters Display */}
                {(searchTerm || filterType !== "all") && (
                  <div className="flex items-center gap-2 text-sm">
                    <span className="text-muted-foreground">Filtros ativos:</span>
                    {searchTerm && (
                      <div className="px-3 py-1 bg-violet-500/10 text-violet-600 rounded-full flex items-center gap-2">
                        <span>Busca: "{searchTerm}"</span>
                        <button onClick={() => setSearchTerm("")} className="hover:text-violet-800">
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    )}
                    {filterType !== "all" && (
                      <div className="px-3 py-1 bg-cyan-500/10 text-cyan-600 rounded-full flex items-center gap-2">
                        <span>{filterType === "with-phone" ? "Com Telefone" : filterType === "with-email" ? "Com Email" : filterType === "with-address" ? "Com Endereço" : "Com Documento"}</span>
                        <button onClick={() => setFilterType("all")} className="hover:text-cyan-800">
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setSearchTerm("");
                        setFilterType("all");
                      }}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      Limpar todos
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Table */}
        <motion.div variants={itemVariants}>
          <Card className="shadow-xl border-border/50 overflow-hidden">
            {isLoading ? (
              <div className="flex items-center justify-center p-12 sm:p-20">
                <div className="text-center space-y-4">
                  <Loader2 className="h-12 w-12 animate-spin text-violet-500 mx-auto" />
                  <p className="text-muted-foreground">Carregando clientes...</p>
                </div>
              </div>
            ) : filteredCustomers && filteredCustomers.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="font-bold">Nome</TableHead>
                      <TableHead className="font-bold hidden sm:table-cell">Email</TableHead>
                      <TableHead className="font-bold hidden md:table-cell">Telefone</TableHead>
                      <TableHead className="font-bold hidden lg:table-cell">Documento</TableHead>
                      <TableHead className="font-bold hidden lg:table-cell">Cidade</TableHead>
                      <TableHead className="text-right font-bold">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <AnimatePresence>
                      {filteredCustomers.map((customer, index) => (
                        <motion.tr
                          key={customer.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: 20 }}
                          transition={{ delay: index * 0.03 }}
                          className="group hover:bg-muted/50 transition-colors"
                        >
                          <TableCell className="font-semibold">
                            <div className="flex items-center gap-2">
                              <div className="h-8 w-8 rounded-full bg-gradient-to-br from-violet-500/20 to-purple-500/20 flex items-center justify-center border border-violet-500/20">
                                <span className="text-xs font-bold text-violet-600">
                                  {customer.name.charAt(0).toUpperCase()}
                                </span>
                              </div>
                              <span className="truncate max-w-[150px] sm:max-w-none">{customer.name}</span>
                            </div>
                          </TableCell>
                          <TableCell className="hidden sm:table-cell">
                            <div className="flex items-center gap-2">
                              <Mail className="h-4 w-4 text-cyan-500" />
                              <span className="truncate max-w-[200px]">{customer.email}</span>
                            </div>
                          </TableCell>
                          <TableCell className="hidden md:table-cell">
                            {customer.phone ? (
                              <div className="flex items-center gap-2">
                                <Phone className="h-4 w-4 text-purple-500" />
                                {customer.phone}
                              </div>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </TableCell>
                          <TableCell className="hidden lg:table-cell">
                            {customer.document ? (
                              <div className="flex items-center gap-2">
                                <FileText className="h-4 w-4 text-purple-500" />
                                {customer.document}
                              </div>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </TableCell>
                          <TableCell className="hidden lg:table-cell">
                            {customer.city ? (
                              <div className="flex items-center gap-2">
                                <MapPin className="h-4 w-4 text-purple-500" />
                                {customer.city}
                              </div>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-1 sm:gap-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 hover:bg-violet-500/10 hover:text-violet-600"
                                onClick={() => handleEdit(customer)}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 hover:bg-red-500/10 hover:text-red-600"
                                onClick={() => handleDeleteClick(customer.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </motion.tr>
                      ))}
                    </AnimatePresence>
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center py-12 sm:py-20 px-4">
                <div className="inline-flex h-16 w-16 sm:h-20 sm:w-20 items-center justify-center rounded-full bg-gradient-to-br from-violet-500/10 to-purple-500/10 mb-4">
                  <Users className="h-8 w-8 sm:h-10 sm:w-10 text-violet-500" />
                </div>
                <h3 className="text-lg sm:text-xl font-semibold mb-2">Nenhum cliente encontrado</h3>
                <p className="text-sm sm:text-base text-muted-foreground mb-6">
                  {searchTerm ? "Tente ajustar os filtros de busca" : "Comece adicionando seu primeiro cliente"}
                </p>
                <Button onClick={handleCreate} size="lg" className="gap-2 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700">
                  <Plus className="h-5 w-5" />
                  Criar Primeiro Cliente
                </Button>
              </div>
            )}
          </Card>
        </motion.div>
      </motion.div>

      {/* Create Dialog */}
      <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">
              Novo Cliente
            </DialogTitle>
            <DialogDescription>
              Preencha as informações do cliente. Campos marcados com * são obrigatórios.
            </DialogDescription>
          </DialogHeader>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              createMutation.mutate(formData);
            }}
            className="space-y-4"
          >
            <div className="space-y-2">
              <Label htmlFor="name" className="text-sm font-semibold">
                Nome Completo <span className="text-red-500">*</span>
              </Label>
              <Input
                id="name"
                placeholder="Ex: João Silva"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="h-11"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-semibold">
                  Email <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="exemplo@email.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  className="h-11"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone" className="text-sm font-semibold">Telefone</Label>
                <Input
                  id="phone"
                  placeholder="(00) 00000-0000"
                  value={formData.phone}
                  onChange={(e) => handlePhoneChange(e.target.value)}
                  className="h-11"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="document" className="text-sm font-semibold">CPF/CNPJ</Label>
              <Input
                id="document"
                placeholder="000.000.000-00 ou 00.000.000/0000-00"
                value={formData.document}
                onChange={(e) => handleDocumentChange(e.target.value)}
                className={`h-11 ${documentError ? "border-red-500" : ""}`}
              />
              {documentError && (
                <p className="text-sm text-red-500 mt-1">{documentError}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="address" className="text-sm font-semibold">Endereço</Label>
              <Input
                id="address"
                placeholder="Rua, Avenida, etc."
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="h-11"
              />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="city" className="text-sm font-semibold">Cidade</Label>
                <Input
                  id="city"
                  placeholder="São Paulo"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  className="h-11"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="state" className="text-sm font-semibold">Estado</Label>
                <Input
                  id="state"
                  placeholder="SP"
                  value={formData.state}
                  onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                  maxLength={2}
                  className="h-11"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="zipCode" className="text-sm font-semibold">CEP</Label>
                <Input
                  id="zipCode"
                  placeholder="00000-000 (preenche endereço automaticamente)"
                  value={formData.zipCode}
                  onChange={(e) => handleZipCodeChange(e.target.value)}
                  className="h-11"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes" className="text-sm font-semibold">Observações</Label>
              <Textarea
                id="notes"
                placeholder="Adicione observações sobre o cliente..."
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
                className="resize-none"
              />
            </div>

            <DialogFooter className="gap-2">
              <Button type="button" variant="outline" onClick={() => setIsCreateOpen(false)}>
                Cancelar
              </Button>
              <Button 
                type="submit" 
                disabled={createMutation.isPending || !!documentError}
                className="bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700"
              >
                {createMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Criar Cliente
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">
              Editar Cliente
            </DialogTitle>
            <DialogDescription>
              Atualize as informações do cliente.
            </DialogDescription>
          </DialogHeader>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (selectedCustomer) {
                updateMutation.mutate({ id: selectedCustomer.id, data: formData });
              }
            }}
            className="space-y-4"
          >
            <div className="space-y-2">
              <Label htmlFor="edit-name" className="text-sm font-semibold">
                Nome Completo <span className="text-red-500">*</span>
              </Label>
              <Input
                id="edit-name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="h-11"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-email" className="text-sm font-semibold">
                  Email <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="edit-email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  className="h-11"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-phone" className="text-sm font-semibold">Telefone</Label>
                <Input
                  id="edit-phone"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="h-11"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-document" className="text-sm font-semibold">CPF/CNPJ</Label>
              <Input
                id="edit-document"
                placeholder="000.000.000-00 ou 00.000.000/0000-00"
                value={formData.document}
                onChange={(e) => handleDocumentChange(e.target.value)}
                className={`h-11 ${documentError ? "border-red-500" : ""}`}
              />
              {documentError && (
                <p className="text-sm text-red-500 mt-1">{documentError}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-address" className="text-sm font-semibold">Endereço</Label>
              <Input
                id="edit-address"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="h-11"
              />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-city" className="text-sm font-semibold">Cidade</Label>
                <Input
                  id="edit-city"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  className="h-11"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-state" className="text-sm font-semibold">Estado</Label>
                <Input
                  id="edit-state"
                  value={formData.state}
                  onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                  maxLength={2}
                  className="h-11"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-zipCode" className="text-sm font-semibold">CEP</Label>
                <Input
                  id="edit-zipCode"
                  value={formData.zipCode}
                  onChange={(e) => setFormData({ ...formData, zipCode: e.target.value })}
                  className="h-11"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-notes" className="text-sm font-semibold">Observações</Label>
              <Textarea
                id="edit-notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
                className="resize-none"
              />
            </div>

            <DialogFooter className="gap-2">
              <Button type="button" variant="outline" onClick={() => setIsEditOpen(false)}>
                Cancelar
              </Button>
              <Button 
                type="submit" 
                disabled={updateMutation.isPending || !!documentError}
                className="bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700"
              >
                {updateMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Salvar Alterações
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteCustomerId} onOpenChange={() => setDeleteCustomerId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-2xl">Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription className="text-base">
              Tem certeza que deseja deletar este cliente? Esta ação não pode ser desfeita e todas as faturas associadas também serão removidas.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Sim, deletar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}
