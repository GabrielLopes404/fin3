import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { XCircle, ArrowLeft, HelpCircle, MessageCircle } from "lucide-react";
import { motion } from "framer-motion";

export default function SubscriptionCancelPage() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-background via-orange-500/5 to-background">
      <div className="max-w-4xl mx-auto px-4 py-16 flex-1 flex items-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, type: "spring" }}
          className="w-full"
        >
          <Card className="p-12 bg-gradient-to-br from-background/80 to-background/40 backdrop-blur-xl border-orange-500/20 text-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
              className="mb-8 inline-block"
            >
              <div className="relative">
                <div className="absolute inset-0 bg-orange-500/20 blur-3xl rounded-full" />
                <div className="relative h-32 w-32 mx-auto rounded-full bg-gradient-to-br from-orange-500 to-amber-600 flex items-center justify-center shadow-2xl">
                  <XCircle className="h-16 w-16 text-white" strokeWidth={3} />
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
            >
              <Badge className="mb-6 bg-gradient-to-r from-orange-600 to-amber-600 border-0 text-white px-6 py-2">
                Checkout Cancelado
              </Badge>

              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Pagamento Cancelado
              </h1>
              
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Tudo bem! Você cancelou o processo de pagamento. Nenhuma cobrança foi realizada.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.6 }}
              className="grid md:grid-cols-2 gap-6 mb-12 max-w-2xl mx-auto"
            >
              <Card className="p-6 bg-gradient-to-br from-blue-500/10 to-cyan-500/5 border-blue-500/20 hover:border-blue-500/40 transition-all">
                <HelpCircle className="h-10 w-10 text-blue-600 mb-3 mx-auto" />
                <h3 className="font-bold mb-2">Tem dúvidas?</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Podemos ajudar você a escolher o melhor plano
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setLocation("/contato")}
                  className="w-full"
                >
                  Falar com Suporte
                </Button>
              </Card>

              <Card className="p-6 bg-gradient-to-br from-violet-500/10 to-fuchsia-500/5 border-violet-500/20 hover:border-violet-500/40 transition-all">
                <MessageCircle className="h-10 w-10 text-violet-600 mb-3 mx-auto" />
                <h3 className="font-bold mb-2">Feedback</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Conte-nos o que aconteceu
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setLocation("/app/help/feedback")}
                  className="w-full"
                >
                  Enviar Feedback
                </Button>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7 }}
              className="p-6 bg-gradient-to-r from-violet-500/10 via-fuchsia-500/10 to-cyan-500/10 rounded-lg mb-8 max-w-2xl mx-auto border border-violet-500/20"
            >
              <h3 className="font-bold mb-3">Por que nossos clientes amam o LUCREI:</h3>
              <div className="grid gap-3 text-left">
                <div className="flex items-start gap-2">
                  <div className="h-6 w-6 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-green-600 text-sm">✓</span>
                  </div>
                  <p className="text-sm">Interface intuitiva e fácil de usar</p>
                </div>
                <div className="flex items-start gap-2">
                  <div className="h-6 w-6 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-green-600 text-sm">✓</span>
                  </div>
                  <p className="text-sm">Suporte dedicado e resposta rápida</p>
                </div>
                <div className="flex items-start gap-2">
                  <div className="h-6 w-6 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-green-600 text-sm">✓</span>
                  </div>
                  <p className="text-sm">Relatórios completos e em tempo real</p>
                </div>
                <div className="flex items-start gap-2">
                  <div className="h-6 w-6 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-green-600 text-sm">✓</span>
                  </div>
                  <p className="text-sm">Cancele quando quiser, sem compromisso</p>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.6 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Button
                size="lg"
                className="bg-gradient-to-r from-violet-600 via-fuchsia-600 to-violet-600 shadow-xl"
                onClick={() => setLocation("/pricing")}
              >
                <ArrowLeft className="mr-2 h-5 w-5" />
                Ver Planos Novamente
              </Button>

              <Button
                size="lg"
                variant="outline"
                onClick={() => setLocation("/")}
              >
                Voltar para Home
              </Button>
            </motion.div>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1, duration: 0.6 }}
              className="text-sm text-muted-foreground mt-8"
            >
              Ainda tem dúvidas? Fale com nosso{" "}
              <button
                onClick={() => setLocation("/contato")}
                className="text-violet-600 hover:underline font-semibold"
              >
                time de vendas
              </button>
            </motion.p>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
