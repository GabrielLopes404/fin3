import { describe, it, expect } from 'vitest';

// Import the password validator
const validatePassword = (password: string): void => {
  const errors: string[] = [];
  
  if (password.length < 8) {
    errors.push('Password must be at least 8 characters');
  }
  
  if (!/[A-Z]/.test(password)) {
    errors.push('Password must contain at least one uppercase letter');
  }
  
  if (!/[a-z]/.test(password)) {
    errors.push('Password must contain at least one lowercase letter');
  }
  
  if (!/[0-9]/.test(password)) {
    errors.push('Password must contain at least one number');
  }
  
  if (!/[^A-Za-z0-9]/.test(password)) {
    errors.push('Password must contain at least one special character');
  }
  
  if (errors.length > 0) {
    throw new Error(errors.join(', '));
  }
};

describe('Password Validator', () => {
  it('should accept a strong password', () => {
    expect(() => validatePassword('Strong!Pass123')).not.toThrow();
  });

  it('should reject password shorter than 8 characters', () => {
    expect(() => validatePassword('Weak1!')).toThrow('Password must be at least 8 characters');
  });

  it('should reject password without uppercase letter', () => {
    expect(() => validatePassword('weak!pass123')).toThrow('uppercase letter');
  });

  it('should reject password without lowercase letter', () => {
    expect(() => validatePassword('STRONG!PASS123')).toThrow('lowercase letter');
  });

  it('should reject password without number', () => {
    expect(() => validatePassword('Strong!Password')).toThrow('number');
  });

  it('should reject password without special character', () => {
    expect(() => validatePassword('StrongPass123')).toThrow('special character');
  });

  it('should accept password with all requirements', () => {
    expect(() => validatePassword('MyP@ssw0rd')).not.toThrow();
    expect(() => validatePassword('Test!123Abc')).not.toThrow();
    expect(() => validatePassword('C0mpl3x#Pass')).not.toThrow();
  });
});
