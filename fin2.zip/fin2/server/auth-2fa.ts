import { authenticator } from 'otplib';
import qrcode from 'qrcode';

export async function generate2FASecret(email: string): Promise<{ secret: string; qrCodeUrl: string }> {
  const secret = authenticator.generateSecret();
  const otpauthUrl = authenticator.keyuri(email, 'LUCREI', secret);
  
  const qrCodeUrl = await qrcode.toDataURL(otpauthUrl);
  
  return {
    secret,
    qrCodeUrl
  };
}

export function verify2FAToken(token: string, secret: string): boolean {
  return authenticator.verify({ token, secret });
}
